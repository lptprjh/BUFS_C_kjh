#include <stdio.h>

int main(){
	int i;
	for(i=0;i<5;i++){
		printf("2�� %d����:%3d\n",i+1,2<<i);
	}
	return 0;
}
